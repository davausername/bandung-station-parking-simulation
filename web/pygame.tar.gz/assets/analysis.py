import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Atur tema agar grafik terlihat profesional di laporan
sns.set_theme(style="whitegrid")
plt.rcParams['font.family'] = 'sans-serif'

# 2. Baca data dari hasil simulasi kamu
# Pastikan nama file sesuai dengan yang diexport oleh main.py
try:
    df = pd.read_csv("simu_results.csv")
except FileNotFoundError:
    print("File data simulasi tidak ditemukan! Jalankan simulasi terlebih dahulu.")
    exit()

# =========================================================
# GRAFIK 1: Tingkat Hunian Parkir (Occupancy Rate)
# =========================================================
plt.figure(figsize=(10, 5))
plt.plot(df['time'], df['occupancy'], color='#e74c3c', linewidth=2, label='Okupansi')
plt.title("Grafik Tingkat Hunian Parkir terhadap Waktu", fontsize=14, pad=15)
plt.xlabel("Jam (In-Game Time)", fontsize=11)
plt.ylabel("Persentase Hunian (%)", fontsize=11)
plt.ylim(0, 105)
plt.xlim(0, 24)
plt.xticks(range(0, 25, 2))  # Menampilkan penanda setiap 2 jam
plt.tight_layout()
plt.savefig("grafik_okupansi.png", dpi=300)  # Menyimpan dengan kualitas tinggi untuk laporan
plt.close()  # Menutup figure agar hemat memori

# =========================================================
# GRAFIK 2: Rata-Rata Kecepatan di Jalan Utama
# =========================================================
plt.figure(figsize=(10, 5))
plt.plot(df['time'], df['avg_speed'], color='#2bc0e4', linewidth=2, label='Kec. Rata-rata')
plt.title("Grafik Dampak Kepadatan terhadap Kecepatan Jalan Utama", fontsize=14, pad=15)
plt.xlabel("Jam (In-Game Time)", fontsize=11)
plt.ylabel("Kecepatan Rata-rata (km/jam)", fontsize=11)
plt.xlim(0, 24)
plt.xticks(range(0, 25, 2))
plt.tight_layout()
plt.savefig("grafik_kecepatan.png", dpi=300)
plt.close()

# =========================================================
# GRAFIK 3: Histogram Distribusi Intent Pengendara
# =========================================================
# (Jika kamu juga me-log data intent mobil yang masuk)
if 'intent' in df.columns:
    plt.figure(figsize=(8, 5))
    sns.countplot(data=df, x='intent', palette='Set2')
    plt.title("Distribusi Orientasi/Intent Kendaraan yang Masuk", fontsize=14, pad=15)
    plt.xlabel("Jenis Intent", fontsize=11)
    plt.ylabel("Jumlah Kendaraan", fontsize=11)
    plt.tight_layout()
    plt.savefig("grafik_distribusi_intent.png", dpi=300)
    plt.close()

print("Semua grafik berhasil dibuat dan disimpan!")