import matplotlib.pyplot as plt
import numpy as np

# 1. Generate 100.000 data acak antara 0.25 dan 1.5
data = np.random.uniform(0.25, 1.5, 100000)

# 2. Membuat histogram
# density=True agar sumbu Y menunjukkan kepadatan peluang (bukan jumlah data)
plt.hist(data, bins=50, density=True, color='skyblue', edgecolor='black', alpha=0.7)

# 3. Menambahkan garis rata-rata (opsional, untuk memperjelas)
plt.axvline(x=0.875, color='red', linestyle='--', label='Rata-rata (0.875)')

# 4. Memberi label dan judul grafik
plt.title('Simulasi Distribusi Uniform Kontinu')
plt.xlabel('Nilai Acak')
plt.ylabel('Kepadatan Peluang')
plt.legend()

# 5. Tampilkan grafik
plt.show()